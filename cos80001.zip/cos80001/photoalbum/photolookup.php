<?php
$uploadDir = "uploads/";
$jsonFile = $uploadDir . "metadata.json";
$photos = file_exists($jsonFile) ? json_decode(file_get_contents($jsonFile), true) : [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $searchTerm = strtolower($_POST["search"] ?? "");
    if ($searchTerm) {
        $photos = array_filter($photos, function($photo) use ($searchTerm) {
            return strpos(strtolower($photo["name"]), $searchTerm) !== false ||
                   strpos(strtolower($photo["photographer"]), $searchTerm) !== false ||
                   strpos(strtolower($photo["description"]), $searchTerm) !== false;
        });
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Lookup</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Photo Lookup</h1>

            <form method="POST" class="form-group">
                <div class="form-group">
                    <label class="label" for="search">Search Photos</label>
                    <input type="text" id="search" name="search" class="input" 
                           placeholder="Search by name, photographer, or description">
                </div>
                <button type="submit" class="button">Search</button>
            </form>

            <div class="result-grid">
                <?php foreach ($photos as $photo): ?>
                    <div class="photo-card">
                        <img src="<?php echo $uploadDir . $photo['filename']; ?>" 
                             alt="<?php echo htmlspecialchars($photo['name']); ?>">
                        <h3><?php echo htmlspecialchars($photo['name']); ?></h3>
                        <p>By: <?php echo htmlspecialchars($photo['photographer']); ?></p>
                        <p><?php echo htmlspecialchars($photo['description']); ?></p>
                        <p class="text-sm">Uploaded: <?php echo $photo['upload_date']; ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

            <div style="margin-top: 1rem;">
                <a href="photouploader.php" class="button">Go to Photo Uploader</a>
            </div>
        </div>
    </div>
    <script src="js/main.js"></script>
</body>
</html>
