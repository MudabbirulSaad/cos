<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uploadDir = "uploads/";
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $photoName = $_POST["photo_name"] ?? "";
    $photographer = $_POST["photographer"] ?? "";
    $description = $_POST["description"] ?? "";

    if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
        $targetFile = $uploadDir . basename($_FILES["photo"]["name"]);
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $targetFile)) {
            // Save metadata to a JSON file
            $metadata = [
                "name" => $photoName,
                "photographer" => $photographer,
                "description" => $description,
                "filename" => basename($_FILES["photo"]["name"]),
                "upload_date" => date("Y-m-d H:i:s")
            ];
            
            $jsonFile = $uploadDir . "metadata.json";
            $existingData = file_exists($jsonFile) ? json_decode(file_get_contents($jsonFile), true) : [];
            $existingData[] = $metadata;
            file_put_contents($jsonFile, json_encode($existingData, JSON_PRETTY_PRINT));
            
            $message = "Photo uploaded successfully!";
        } else {
            $error = "Sorry, there was an error uploading your file.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Uploader</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Photo Uploader</h1>
            
            <?php if (isset($message)): ?>
                <div class="alert success"><?php echo $message; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert error"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="label" for="photo">Select Photo</label>
                    <input type="file" id="photo" name="photo" class="input" accept="image/*" required>
                    <img id="preview" style="display: none; max-width: 200px; margin-top: 1rem;">
                </div>

                <div class="form-group">
                    <label class="label" for="photo_name">Photo Name</label>
                    <input type="text" id="photo_name" name="photo_name" class="input" required>
                </div>

                <div class="form-group">
                    <label class="label" for="photographer">Photographer</label>
                    <input type="text" id="photographer" name="photographer" class="input" required>
                </div>

                <div class="form-group">
                    <label class="label" for="description">Description</label>
                    <textarea id="description" name="description" class="input" rows="3" required></textarea>
                </div>

                <button type="submit" class="button">Upload Photo</button>
            </form>
            
            <div style="margin-top: 1rem;">
                <a href="photolookup.php" class="button">Go to Photo Lookup</a>
            </div>
        </div>
    </div>
    <script src="js/main.js"></script>
</body>
</html>
