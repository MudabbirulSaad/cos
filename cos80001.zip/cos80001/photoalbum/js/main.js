document.addEventListener('DOMContentLoaded', function() {
    // File input preview
    const fileInput = document.querySelector('input[type="file"]');
    const preview = document.getElementById('preview');
    
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });
    }

    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredInputs = form.querySelectorAll('[required]');
            requiredInputs.forEach(input => {
                if (!input.value) {
                    e.preventDefault();
                    input.classList.add('error');
                }
            });
        });
    });

    // Animate elements when they come into view
    const observeElements = () => {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.photo-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            observer.observe(card);
        });
    };

    // Add loading state to buttons
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            const button = form.querySelector('button[type="submit"]');
            if (button && !button.classList.contains('loading')) {
                button.classList.add('loading');
                button.disabled = true;
                
                // Simulate loading state (remove in production)
                setTimeout(() => {
                    button.classList.remove('loading');
                    button.disabled = false;
                }, 1000);
            }
        });
    });

    // Smooth scroll to top
    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    // Add scroll to top button if page is long
    if (document.body.scrollHeight > window.innerHeight * 2) {
        const scrollButton = document.createElement('button');
        scrollButton.className = 'button scroll-top';
        scrollButton.innerHTML = '↑';
        scrollButton.style.position = 'fixed';
        scrollButton.style.bottom = '20px';
        scrollButton.style.right = '20px';
        scrollButton.style.borderRadius = '50%';
        scrollButton.style.width = '40px';
        scrollButton.style.height = '40px';
        scrollButton.style.padding = '0';
        scrollButton.style.opacity = '0';
        scrollButton.style.transition = 'opacity 0.3s ease';
        
        document.body.appendChild(scrollButton);
        
        scrollButton.addEventListener('click', scrollToTop);
        
        window.addEventListener('scroll', () => {
            scrollButton.style.opacity = window.scrollY > 500 ? '1' : '0';
        });
    }

    // Initialize animations
    observeElements();
}); 
